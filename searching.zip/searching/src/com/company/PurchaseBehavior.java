package com.company;

public interface PurchaseBehavior {
    public void purchasing();
}
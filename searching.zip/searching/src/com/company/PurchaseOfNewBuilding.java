package com.company;

public class PurchaseOfNewBuilding implements PurchaseBehavior{
    @Override
    public void purchasing(){
        System.out.println("purchase of new building");}
}
package com.company;

public class DailyRent implements RentBehavior{
    @Override
    public void renting(){
        System.out.println("Daily Renting");
    }
}
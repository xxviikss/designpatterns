package com.company;

public class LongTermRent implements RentBehavior{
    @Override
    public void renting(){
        System.out.println("Long-term Renting");
    }
}
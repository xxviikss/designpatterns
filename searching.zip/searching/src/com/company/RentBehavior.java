package com.company;

public interface RentBehavior {
    public void renting();
}
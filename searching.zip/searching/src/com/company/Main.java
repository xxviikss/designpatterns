package com.company;

public class Main {

    public static void main(String[] args) {
        PrivateHouseSearch privateHouseSearch = new PrivateHouseSearch();
        privateHouseSearch.display();
        privateHouseSearch.performPurchasing();
        privateHouseSearch.performRenting();

        ApartmentSearch apartmentSearch = new ApartmentSearch();
        apartmentSearch.display();
        apartmentSearch.performRenting();
        apartmentSearch.performPurchasing();

    }
}
